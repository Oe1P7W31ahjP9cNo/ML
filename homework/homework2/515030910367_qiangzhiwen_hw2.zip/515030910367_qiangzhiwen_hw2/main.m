pair_size=108;
uniform_entropy=zeros(1,pair_size);
uniform_integral=zeros(1,pair_size);
Gaussian_entropy=zeros(1,pair_size);
Gaussian_integral=zeros(1,pair_size);
for i=1:pair_size 
    file_name2=num2str(i);
    switch size(file_name2,2)
        case 1
            file_name1='000';
        case 2
            file_name1='00';
        case 3 
            file_name1='0';
    end
    file_path=['dataset/pair',file_name1,file_name2,'.txt'];
    data=load (file_path);
    x=data(:,1);
    y=data(:,2);
    if igci(x,y,1,1)<0 
        uniform_entropy(i)=1;
    else
        uniform_entropy(i)=-1;
    end
    if igci(x,y,1,2)<0 
        uniform_integral(i)=1;
    else
        uniform_integral(i)=-1;
    end
    if igci(x,y,2,1)<0 
        Gaussian_entropy(i)=1;
    else
        Gaussian_entropy(i)=-1;
    end
    if igci(x,y,2,2)<0 
        Gaussian_integral(i)=1;
    else
        Gaussian_integral(i)=-1;
    end
end
load dataset/target.txt;
result1=1-sum(abs(target-uniform_entropy))/(2*pair_size);
result2=1-sum(abs(target-uniform_integral))/(2*pair_size);
result3=1-sum(abs(target-Gaussian_entropy))/(2*pair_size);
result4=1-sum(abs(target-Gaussian_integral))/(2*pair_size);

fprintf('%s %f%s\n','result obtianed uniform_entropy manner',result1,'%')
fprintf('%s %f%s\n','result obtianed uniform_integral manner',result2,'%')
fprintf('%s %f%s\n','result obtianed Gaussian_entropy manner',result3,'%')
fprintf('%s %f%s\n','result obtianed Gaussian_integral manner',result4,'%')

    